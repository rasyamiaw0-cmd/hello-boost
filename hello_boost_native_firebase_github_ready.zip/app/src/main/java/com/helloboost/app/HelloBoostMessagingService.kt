package com.helloboost.app
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import androidx.core.app.NotificationCompat
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import kotlinx.coroutines.*

class HelloBoostMessagingService:FirebaseMessagingService(){
 override fun onNewToken(token:String){CoroutineScope(Dispatchers.IO).launch{FirebaseRepository.saveFcmToken(token)}}
 override fun onMessageReceived(m:RemoteMessage){
  val ch="hello_boost_orders"; val nm=getSystemService(NotificationManager::class.java)
  if(Build.VERSION.SDK_INT>=26)nm.createNotificationChannel(NotificationChannel(ch,"Pesanan",NotificationManager.IMPORTANCE_DEFAULT))
  nm.notify(System.currentTimeMillis().toInt(),NotificationCompat.Builder(this,ch)
   .setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle(m.notification?.title?:"hello_boost")
   .setContentText(m.notification?.body?:"Status pesanan diperbarui").setAutoCancel(true).build())
 }
}