package com.helloboost.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.NumberFormat
import java.util.Locale

data class Product(val name:String, val price:Int, val target:String, val minOrder:Int)
data class CartItem(val product:Product, val qty:Int, val reaction:String? = null)

private val Pink = Color(0xFFED5B95)
private val Pink2 = Color(0xFFFF79AD)
private val Bg = Color(0xFF09090C)
private val Card = Color(0xFF19181E)
private val TextMain = Color(0xFFF7F4F7)
private val Muted = Color(0xFFAAA5AD)

private val catalog = {
        "Instagram" to listOf(Product("Followers Indonesia", 50000, "Followers Instagram", 100), Product("Followers Luar", 10000, "Followers Instagram Luar", 10), Product("Like Indonesia", 20000, "Like Instagram", 100), Product("Like Luar", 2000, "Like Instagram Luar", 10), Product("View", 2000, "View Instagram", 100), Product("Komen", 350000, "Komentar Instagram", 20), Product("Komentar Luar (Custom)", 20000, "Komentar Instagram Luar (Custom)", 20), Product("View Story", 1000, "View Story Instagram", 100), Product("Like Story", 25000, "Like Story Instagram", 100), Product("Live", 20000, "View Live Instagram", 100), Product("Repost", 8000, "Repost Instagram", 100)),
        "TikTok" to listOf(Product("Followers Indonesia", 100000, "Followers TikTok", 50), Product("Followers Luar", 32000, "Followers TikTok Luar", 10), Product("Like Indonesia", 30000, "Like TikTok", 100), Product("Like Luar", 5000, "Like TikTok Luar", 50), Product("View", 2000, "View TikTok", 100), Product("Komentar", 100000, "Komentar TikTok", 20)),
        "WhatsApp" to listOf(Product("Followers Saluran", 15000, "Followers Channel WhatsApp", 100), Product("Reaksi Postingan", 1000, "Reaksi Postingan WhatsApp", 10)),
        "Facebook" to listOf(Product("View", 3000, "View Facebook", 100), Product("Member Grup", 5000, "Member Grup Facebook", 100), Product("Followers Indonesia", 130000, "Followers Facebook", 100), Product("Like Indonesia", 110000, "Like Facebook", 100), Product("Komen", 300000, "Komentar Facebook", 20)),
        "Shopee" to listOf(Product("Followers", 10000, "Followers Shopee", 100), Product("Like Indonesia", 10000, "Like Shopee", 100), Product("Live", 70000, "Penonton Live Shopee", 100)),
        "Telegram" to listOf(Product("Followers", 5000, "Followers Telegram", 100), Product("View Story", 5000, "View Story Telegram", 100)),
        "Threads" to listOf(Product("Followers", 100000, "Followers Threads", 100), Product("Like", 25000, "Like Threads", 100)),
        "Spotify" to listOf(Product("Followers", 150000, "Followers Spotify", 100)),
        "X" to listOf(Product("Followers", 200000, "Followers X", 100), Product("Like", 60000, "Like X", 100), Product("View", 500, "View X", 100)),
        "Roblox" to listOf(Product("Followers Indonesia", 130000, "Followers Roblox", 100), Product("Friends Indonesia", 50000, "Friends Roblox", 100)),
        "Tokopedia" to listOf(Product("Followers", 130000, "Followers Tokopedia", 100)),
        "Twitch" to listOf(Product("Followers", 40000, "Followers Twitch", 100)),
        "LinkedIn" to listOf(Product("Followers", 2200000, "Followers LinkedIn", 100), Product("Like", 650000, "Like LinkedIn", 100))
    }
private const val WA = "6283179090525"

private fun rupiah(n:Int) = NumberFormat.getCurrencyInstance(Locale("id","ID"))
    .format(n).replace(",00","").replace("Rp","Rp ")

class MainActivity: ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { HelloBoostApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HelloBoostApp() {
    var platform by remember { mutableStateOf("Instagram") }
    var cart by remember { mutableStateOf(listOf<CartItem>()) }
    var search by remember { mutableStateOf("") }
    var showCart by remember { mutableStateOf(false) }
    var selectedReaction by remember { mutableStateOf<String?>(null) }
    var toast by remember { mutableStateOf<String?>(null) }
    val context = LocalContext.current

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Pink, background = Bg, surface = Card,
        onBackground = TextMain, onSurface = TextMain
    )) {
        Scaffold(
            containerColor = Bg,
            topBar = {
                TopAppBar(
                    title = { Text("hello_boost", fontWeight=FontWeight.Bold) },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = Bg, titleContentColor = TextMain
                    ),
                    actions = {
                        IconButton(onClick={ showCart=true }) {
                            BadgedBox(badge={ if(cart.isNotEmpty()) Badge { Text(cart.size.toString()) } }) {
                                Icon(Icons.Default.ShoppingCart, "Pesanan", tint=Pink2)
                            }
                        }
                    }
                )
            },
            bottomBar = {
                NavigationBar(containerColor = Card) {
                    NavigationBarItem(selected=!showCart, onClick={ showCart=false },
                        icon={ Icon(Icons.Default.Home, null) }, label={ Text("Beranda") })
                    NavigationBarItem(selected=showCart, onClick={ showCart=true },
                        icon={ Icon(Icons.Default.ShoppingCart, null) }, label={ Text("Pesanan") })
                    NavigationBarItem(selected=false, onClick={
                        context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/$WA")))
                    }, icon={ Icon(Icons.Default.Chat, null) }, label={ Text("Admin") })
                }
            }
        ) { pad ->
            Box(Modifier.fillMaxSize().padding(pad)) {
                if(showCart) {
                    CartScreen(cart, onBack={showCart=false}, onRemove={ item ->
                        cart = cart.toMutableList().also { it.remove(item) }
                    }, onCheckout={
                        val msg = buildString {
                            append("Halo hello_boost, saya ingin order:%0A")
                            cart.forEach { append("- ${it.product.name} x ${it.qty}%0A") }
                            append("%0ATotal: ${rupiah(cart.sumOf{ it.product.price * it.qty / 1000 })}")
                        }
                        context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/$WA?text=$msg")))
                    })
                } else {
                    HomeScreen(
                        platform, {platform=it}, search, {search=it},
                        selectedReaction, {selectedReaction=it},
                        onAdd={ product, qty, reaction ->
                            if(qty < product.minOrder) {
                                toast = "Minimal order ${product.minOrder}"
                            } else if(product.name.contains("Reaksi", true) && reaction == null) {
                                toast = "Pilih salah satu reaksi terlebih dahulu."
                            } else {
                                cart = cart + CartItem(product, qty, reaction)
                                toast = "Ditambahkan ke pesanan"
                            }
                        }
                    )
                }
                toast?.let { message ->
                    LaunchedEffect(message) {
                        kotlinx.coroutines.delay(1800); toast=null
                    }
                    SnackbarHost(Modifier.align(Alignment.BottomCenter),
                        hostState=remember { SnackbarHostState() }) { Text(message) }
                }
            }
        }
    }
}

@Composable
fun HomeScreen(
    platform:String, onPlatform:(String)->Unit, search:String, onSearch:(String)->Unit,
    selectedReaction:String?, onReaction:(String?)->Unit,
    onAdd:(Product,Int,String?)->Unit
) {
    val platforms = catalog.keys.toList()
    val products = catalog[platform].orEmpty().filter {
        search.isBlank() || it.name.contains(search,true) || it.target.contains(search,true)
    }
    LazyColumn(
        contentPadding=PaddingValues(16.dp),
        verticalArrangement=Arrangement.spacedBy(14.dp)
    ) {
        item {
            Card(shape=RoundedCornerShape(22.dp), colors=CardDefaults.cardColors(
                containerColor=Card
            )) {
                Column(Modifier.padding(20.dp)) {
                    Text("Boost Social Media", fontSize=26.sp, fontWeight=FontWeight.Bold)
                    Text("Lebih mudah dengan hello_boost.", color=Muted)
                    Spacer(Modifier.height(12.dp))
                    Text("⚡ Proses cepat   •   💗 Harga transparan", color=Pink2)
                }
            }
        }
        item {
            Text("AKUN WAJIB TIDAK DI PRIVATE !!", color=Color(0xFFFFD34D),
                fontWeight=FontWeight.ExtraBold, fontSize=16.sp)
        }
        item {
            OutlinedTextField(value=search, onValueChange=onSearch,
                modifier=Modifier.fillMaxWidth(), label={Text("Cari layanan")},
                leadingIcon={Icon(Icons.Default.Search,null)})
        }
        item {
            Text("Platform", fontWeight=FontWeight.Bold, fontSize=18.sp)
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth().horizontalScroll(
                androidx.compose.foundation.rememberScrollState()
            ), horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                platforms.forEach { p ->
                    FilterChip(selected=p==platform, onClick={onPlatform(p)},
                        label={Text(p)})
                }
            }
        }
        items(products) { product ->
            ProductCard(product, selectedReaction, onReaction, onAdd)
        }
        item {
            Card(shape=RoundedCornerShape(18.dp), colors=CardDefaults.cardColors(containerColor=Card)) {
                Column(Modifier.padding(16.dp)) {
                    Text("Keamanan", fontWeight=FontWeight.Bold)
                    Text("Jangan berikan password, OTP, kode login atau recovery code kepada siapapun.",
                        color=Muted)
                }
            }
        }
    }
}

@Composable
fun ProductCard(product:Product, selectedReaction:String?, onReaction:(String?)->Unit,
                onAdd:(Product,Int,String?)->Unit) {
    var qtyText by remember(product.name) { mutableStateOf(product.minOrder.toString()) }
    val isReaction = product.name.contains("Reaksi", true)
    Card(shape=RoundedCornerShape(18.dp), colors=CardDefaults.cardColors(containerColor=Card)) {
        Column(Modifier.padding(16.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.SpaceBetween) {
                Column(Modifier.weight(1f)) {
                    Text(product.name, fontWeight=FontWeight.Bold, fontSize=17.sp)
                    Text("Minimal ${product.minOrder}", color=Muted, fontSize=13.sp)
                }
                Text(rupiah(product.price) + "/k", color=Pink2, fontWeight=FontWeight.Bold)
            }
            Spacer(Modifier.height(10.dp))
            if(isReaction) {
                Text("Reaksi postingan", color=Muted, fontSize=13.sp)
                Row(horizontalArrangement=Arrangement.spacedBy(6.dp), modifier=Modifier.padding(vertical=8.dp)) {
                    listOf("❤️","😂","😮","😢","😡","👍").forEach { r ->
                        FilterChip(selected=selectedReaction==r, onClick={onReaction(r)}, label={Text(r)})
                    }
                }
                FilterChip(selected=selectedReaction=="RANDOM", onClick={onReaction("RANDOM")},
                    label={Text("🎲 Random")})
                Spacer(Modifier.height(8.dp))
            }
            OutlinedTextField(
                value=qtyText, onValueChange={ qtyText=it.filter(Char::isDigit) },
                modifier=Modifier.fillMaxWidth(), label={Text("Jumlah")},
                singleLine=true
            )
            Spacer(Modifier.height(10.dp))
            Button(onClick={
                val qty=qtyText.toIntOrNull() ?: 0
                onAdd(product, qty, if(isReaction) selectedReaction else null)
            }, modifier=Modifier.fillMaxWidth()) {
                Icon(Icons.Default.AddShoppingCart,null)
                Spacer(Modifier.width(8.dp))
                Text("Tambah ke pesanan")
            }
        }
    }
}

@Composable
fun CartScreen(cart:List<CartItem>, onBack:()->Unit, onRemove:(CartItem)->Unit, onCheckout:()->Unit) {
    val total = cart.sumOf { it.product.price * it.qty / 1000 }
    LazyColumn(contentPadding=PaddingValues(16.dp), verticalArrangement=Arrangement.spacedBy(12.dp)) {
        item {
            Row(verticalAlignment=Alignment.CenterVertically) {
                IconButton(onClick=onBack) { Icon(Icons.Default.ArrowBack,null) }
                Text("Pesanan", fontSize=24.sp, fontWeight=FontWeight.Bold)
            }
        }
        if(cart.isEmpty()) item { Text("Keranjang masih kosong.", color=Muted) }
        items(cart) { item ->
            Card(colors=CardDefaults.cardColors(containerColor=Card), shape=RoundedCornerShape(16.dp)) {
                Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment=Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(item.product.name, fontWeight=FontWeight.Bold)
                        Text("${item.qty} • ${rupiah(item.product.price * item.qty / 1000)}",
                            color=Pink2)
                        item.reaction?.let { Text("Reaksi: $it", color=Muted) }
                    }
                    IconButton(onClick={onRemove(item)}) { Icon(Icons.Default.Delete,null) }
                }
            }
        }
        if(cart.isNotEmpty()) {
            item {
                Card(colors=CardDefaults.cardColors(containerColor=Card)) {
                    Column(Modifier.padding(16.dp)) {
                        Text("Total", color=Muted)
                        Text(rupiah(total), fontSize=24.sp, fontWeight=FontWeight.Bold)
                        Spacer(Modifier.height(10.dp))
                        Button(onClick=onCheckout, modifier=Modifier.fillMaxWidth()) {
                            Icon(Icons.Default.WhatsApp,null)
                            Spacer(Modifier.width(8.dp))
                            Text("Lanjut via WhatsApp")
                        }
                    }
                }
            }
        }
    }
}
