package com.helloboost.app
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import com.google.firebase.firestore.ListenerRegistration
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.launch

class AdminActivity:ComponentActivity(){override fun onCreate(b:Bundle?){super.onCreate(b);setContent{AdminPanel()}}}
@Composable fun AdminPanel(){
 val sts=listOf("Menunggu Pembayaran","Dibayar","Diproses","Selesai","Dibatalkan"); var orders by remember{mutableStateOf(listOf<OrderRecord>())}
 DisposableEffect(Unit){val l:ListenerRegistration=FirebaseRepository.allOrders().addSnapshotListener{snap,_->
  orders=snap?.documents?.map{d->OrderRecord(d.id,d.getString("orderCode")?:"",d.getString("userId")?:"",
   d.getString("service")?:"",d.getString("platform")?:"",d.getString("target")?:"",
   (d.getLong("qty")?:0).toInt(),d.getString("reaction"),(d.getLong("total")?:0).toInt(),d.getString("status")?:"")}?:emptyList()}
  onDispose{l.remove()}}
 LazyColumn(contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
  item{Text("Panel Admin • hello_boost",fontWeight=FontWeight.Bold)}
  items(orders){o->Card{Column(Modifier.padding(14.dp)){
   Text(o.orderCode,color=Color(0xFFFF79AD),fontWeight=FontWeight.Bold);Text(o.service);Text("User: ${o.userId}")
   Text("Jumlah: ${o.qty} • Total: Rp ${o.total}");Text("Status: ${o.status}")
   sts.filter{it!=o.status}.forEach{st->TextButton(onClick={MainScope().launch{FirebaseRepository.setOrderStatus(o.id,st)}}){Text("→ $st")}}
  }}}
 }}
}