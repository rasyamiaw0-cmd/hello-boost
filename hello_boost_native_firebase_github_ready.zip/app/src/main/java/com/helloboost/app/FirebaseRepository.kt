package com.helloboost.app
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import kotlinx.coroutines.tasks.await
import java.util.UUID

data class OrderRecord(val id:String="",val orderCode:String="",val userId:String="",val service:String="",
 val platform:String="",val target:String="",val qty:Int=0,val reaction:String?=null,val total:Int=0,
 val status:String="Menunggu Pembayaran")

object FirebaseRepository {
 val auth=FirebaseAuth.getInstance()
 private val db=FirebaseFirestore.getInstance()
 suspend fun register(name:String,email:String,password:String,phone:String)=runCatching{
  val u=auth.createUserWithEmailAndPassword(email,password).await().user!!
  db.collection("users").document(u.uid).set(mapOf("uid" to u.uid,"name" to name,"email" to email,
   "phone" to phone,"createdAt" to com.google.firebase.firestore.FieldValue.serverTimestamp())).await()
 }
 suspend fun login(email:String,password:String)=runCatching{auth.signInWithEmailAndPassword(email,password).await()}
 fun logout()=auth.signOut()
 suspend fun createOrder(item:CartItem,platform:String,target:String)=runCatching{
  val uid=auth.currentUser?.uid?:error("Silakan login")
  val id=UUID.randomUUID().toString(); val code="HB-"+id.take(8).uppercase()
  db.collection("orders").document(id).set(mapOf("orderCode" to code,"userId" to uid,
   "service" to item.product.name,"platform" to platform,"target" to target,"qty" to item.qty,
   "reaction" to item.reaction,"total" to item.product.price*item.qty/1000,
   "status" to "Menunggu Pembayaran","createdAt" to com.google.firebase.firestore.FieldValue.serverTimestamp())).await()
  code
 }
 fun userOrders(uid:String)=db.collection("orders").whereEqualTo("userId",uid).orderBy("createdAt",Query.Direction.DESCENDING)
 fun allOrders()=db.collection("orders").orderBy("createdAt",Query.Direction.DESCENDING)
 suspend fun setOrderStatus(id:String,status:String){db.collection("orders").document(id).update("status",status).await()}
 suspend fun saveFcmToken(token:String){
  val uid=auth.currentUser?.uid?:return
  db.collection("devices").document(token.take(120)).set(mapOf("userId" to uid,"token" to token,
   "updatedAt" to com.google.firebase.firestore.FieldValue.serverTimestamp())).await()
 }
}