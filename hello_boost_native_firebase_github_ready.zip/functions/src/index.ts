import {onDocumentUpdated} from "firebase-functions/v2/firestore";
import {initializeApp} from "firebase-admin/app";
import {getFirestore,FieldValue} from "firebase-admin/firestore";
import {getMessaging} from "firebase-admin/messaging";
initializeApp(); const db=getFirestore();
export const notifyOrderStatus=onDocumentUpdated("orders/{orderId}",async e=>{
 const before=e.data?.before.data(),after=e.data?.after.data(); if(!before||!after||before.status===after.status)return;
 const uid=after.userId;if(!uid)return;
 const snap=await db.collection("devices").where("userId","==",uid).get();
 const tokens=snap.docs.map(d=>d.data().token).filter(Boolean);
 const title="hello_boost • Status Pesanan";
 const body=`Pesanan ${after.orderCode??e.params.orderId}: ${after.status}`;
 if(tokens.length)await getMessaging().sendEachForMulticast({tokens,notification:{title,body},data:{orderId:e.params.orderId,status:String(after.status)}});
 await db.collection("users").doc(uid).collection("notifications").add({title,body,orderId:e.params.orderId,status:after.status,createdAt:FieldValue.serverTimestamp(),read:false});
});