# Firebase hello_boost

1. Buat project di Firebase Console.
2. Tambahkan Android app dengan package `com.helloboost.app`.
3. Download `google-services.json` → simpan sebagai `app/google-services.json`.
4. Authentication → Sign-in method → Email/Password → Enable.
5. Buat Firestore Database.
6. Install Firebase CLI: `npm install -g firebase-tools`
7. `firebase login`
8. `firebase use PROJECT_ID`
9. `firebase deploy --only firestore`
10. `cd functions && npm install && npm run build && cd .. && firebase deploy --only functions`

## Admin
Buat `admins/UID_ADMIN` di Firestore dengan field `role: "admin"`.
Lebih aman lagi gunakan custom claim `admin=true` dari Admin SDK.

## Data
users/{uid}
orders/{orderId}
devices/{token}
users/{uid}/notifications/{notificationId}
