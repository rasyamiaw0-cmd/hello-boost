# hello_boost Native + Firebase

Fondasi native Android untuk hello_boost dengan Firebase Authentication, Firestore order/status,
FCM token + Cloud Function notifikasi, Firestore security rules, dan AdminActivity.

Konfigurasi Firebase milik pemilik aplikasi belum tersedia, jadi `app/google-services.json` harus
diambil dari project Firebase milik kamu. Lihat FIREBASE_SETUP.md.

Build: buka folder di Android Studio → Sync → Build APK(s).
